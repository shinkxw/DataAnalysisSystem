$c.run("create table test (id int not null, str varchar(32) not null)")
