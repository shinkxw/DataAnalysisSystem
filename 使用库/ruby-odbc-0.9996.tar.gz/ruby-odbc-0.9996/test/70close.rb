$c.disconnect
