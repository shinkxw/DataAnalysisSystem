$c = ODBC.connect($dsn, $uid, $pwd)
