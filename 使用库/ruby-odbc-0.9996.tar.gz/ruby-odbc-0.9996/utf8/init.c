/*
 * Part of ODBC-Ruby binding
 * Copyright (c) 2006-2007 Christian Werner <chw@ch-werner.de>
 *
 * See the file "COPYING" for information on usage
 * and redistribution of this file and for a
 * DISCLAIMER OF ALL WARRANTIES.
 *
 * $Id: init.c,v 1.2 2007/04/07 09:39:08 chw Exp chw $
 */

#include "../init.c"
