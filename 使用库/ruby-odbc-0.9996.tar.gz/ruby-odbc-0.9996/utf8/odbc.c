/*
 * ODBC-Ruby binding
 * Copyright (c) 2001-2007 Christian Werner <chw@ch-werner.de>
 *
 * See the file "COPYING" for information on usage
 * and redistribution of this file and for a
 * DISCLAIMER OF ALL WARRANTIES.
 *
 * $Id: odbc.c,v 1.3 2007/04/07 09:39:08 chw Exp chw $
 */

#define UNICODE
#define _UNICODE

#include "../odbc.c"
