drop view view_names;
---
drop table names;
---
drop table blob_test;
---
drop table boolean_test;
---
drop table time_test;
---
drop table timestamp_test;
---
drop table bit_test;
---
drop table field_types_test;
---
drop table db_specific_types_test;
---
drop table precision_test;
